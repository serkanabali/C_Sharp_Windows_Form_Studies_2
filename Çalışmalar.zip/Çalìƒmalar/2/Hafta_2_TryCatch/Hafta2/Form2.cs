﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta2
{
    //Form 2 in başlangıçta açılması için program.cs>application.run değiştir
    
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        List<string> liste = new List<string>();
        string[] dizi = new string[] { "2", "4", "6" };

        private void Form2_Load(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = -2;
            numericUpDown1.Maximum = 3;

            lst_elemanlar.Items.Add("5");
            lst_elemanlar.Items.Add("10");
            lst_elemanlar.Items.Add("15");

            liste.Add("3");
            liste.Add("5");
            liste.Add("7");
        }

        private void btn_getir_Click(object sender, EventArgs e)
        {
            try
            {
                int indis = Convert.ToInt32(numericUpDown1.Value);

                //  1- String.Format ve String.Join ile yazdırma
                label1.Text = String.Format(String.Join("-", "{0}", "{1}", "{2}"),
                lst_elemanlar.Items[indis], liste[indis], dizi[indis]);
                
                //  2- String.Format yazımı
                //  label1.Text = String.Format("{0}-{1}-{2}", lst_elemanlar.Items[indis], liste[indis], dizi[indis]);

                //  3- String.Join yazımı
                //  label1.Text = String.Join("-", lst_elemanlar.Items[indis], liste[indis], dizi[indis]);

                //  4- Düz string yazımı
                //  label1.Text = lst_elemanlar.Items[indis] + "-" + liste[indis] + dizi[indis];
            }
            catch (ArgumentOutOfRangeException)
            {
                label1.Text="Yanlış indis numarası girdiniz.";
            }
            
        }

        private void btn_listbox_Click(object sender, EventArgs e)
        {
            try
            {
                int indis = Convert.ToInt32(numericUpDown1.Value);
                label1.Text = lst_elemanlar.Items[indis].ToString();
            }
            catch (ArgumentOutOfRangeException)     //Birden fazla özel durum için kullanılabilir.
            {
                label1.Text= "ListBox için yanlış indis numarası girdiniz";
            }           
        }

        private void btn_liste_Click(object sender, EventArgs e)
        {
            try
            {
                int indis = Convert.ToInt32(numericUpDown1.Value);
                label1.Text = liste[indis].ToString();

            }
            catch (ArgumentOutOfRangeException)
            {
                label1.Text = "Liste için yanlış indis numarası girdiniz";
            }
        }

        private void btn_dizi_Click(object sender, EventArgs e)
        {
            try
            {
                int indis = Convert.ToInt32(numericUpDown1.Value);
                label1.Text = dizi[indis].ToString();

            }
            catch (IndexOutOfRangeException)
            {
                label1.Text = "Dizi için yanlış indis numarası girdiniz";
            }
        }
    }
}
