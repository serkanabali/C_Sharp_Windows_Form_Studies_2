﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //ComboBox elemanlarını kod içinden yazma
        private void Form1_Load(object sender, EventArgs e)
        {
            cb_yetki.Items.Add("Admin");
            cb_yetki.Items.Add("Kullanıcı");
        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            
            string kAdi = "";
            int sifre = 0;
            int yetki = 0;
            
            try
            {
                //VT ye alternatif fakat güvenilir değil
                kAdi = tb_kullanici.Text;
                sifre = Convert.ToInt32(tb_sifre.Text);
                yetki = cb_yetki.SelectedIndex;

                if (kAdi == "serkan" && sifre == 123 && yetki == 1
                    || kAdi == "abalı" && sifre == 111 && yetki == 0)
                {
                    Form2 f = new Form2();
                    f.Show();
                }

                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre yanlış");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Şifre sayı olmalıdır");
            }

        }

    }
}
