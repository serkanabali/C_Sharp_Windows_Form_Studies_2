﻿namespace Hafta2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lst_elemanlar = new System.Windows.Forms.ListBox();
            this.btn_getir = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btn_listbox = new System.Windows.Forms.Button();
            this.btn_dizi = new System.Windows.Forms.Button();
            this.btn_liste = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(148, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // lst_elemanlar
            // 
            this.lst_elemanlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lst_elemanlar.FormattingEnabled = true;
            this.lst_elemanlar.ItemHeight = 25;
            this.lst_elemanlar.Location = new System.Drawing.Point(8, 12);
            this.lst_elemanlar.Name = "lst_elemanlar";
            this.lst_elemanlar.Size = new System.Drawing.Size(134, 179);
            this.lst_elemanlar.TabIndex = 1;
            // 
            // btn_getir
            // 
            this.btn_getir.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_getir.Location = new System.Drawing.Point(8, 234);
            this.btn_getir.Name = "btn_getir";
            this.btn_getir.Size = new System.Drawing.Size(134, 42);
            this.btn_getir.TabIndex = 2;
            this.btn_getir.Text = "Getir";
            this.btn_getir.UseVisualStyleBackColor = true;
            this.btn_getir.Click += new System.EventHandler(this.btn_getir_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericUpDown1.Location = new System.Drawing.Point(8, 198);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(134, 30);
            this.numericUpDown1.TabIndex = 3;
            // 
            // btn_listbox
            // 
            this.btn_listbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_listbox.Location = new System.Drawing.Point(148, 53);
            this.btn_listbox.Name = "btn_listbox";
            this.btn_listbox.Size = new System.Drawing.Size(134, 42);
            this.btn_listbox.TabIndex = 4;
            this.btn_listbox.Text = "ListBox";
            this.btn_listbox.UseVisualStyleBackColor = true;
            this.btn_listbox.Click += new System.EventHandler(this.btn_listbox_Click);
            // 
            // btn_dizi
            // 
            this.btn_dizi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dizi.Location = new System.Drawing.Point(148, 149);
            this.btn_dizi.Name = "btn_dizi";
            this.btn_dizi.Size = new System.Drawing.Size(134, 42);
            this.btn_dizi.TabIndex = 5;
            this.btn_dizi.Text = "Dizi";
            this.btn_dizi.UseVisualStyleBackColor = true;
            this.btn_dizi.Click += new System.EventHandler(this.btn_dizi_Click);
            // 
            // btn_liste
            // 
            this.btn_liste.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_liste.Location = new System.Drawing.Point(148, 101);
            this.btn_liste.Name = "btn_liste";
            this.btn_liste.Size = new System.Drawing.Size(134, 42);
            this.btn_liste.TabIndex = 6;
            this.btn_liste.Text = "Liste";
            this.btn_liste.UseVisualStyleBackColor = true;
            this.btn_liste.Click += new System.EventHandler(this.btn_liste_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_liste);
            this.Controls.Add(this.btn_dizi);
            this.Controls.Add(this.btn_listbox);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btn_getir);
            this.Controls.Add(this.lst_elemanlar);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lst_elemanlar;
        private System.Windows.Forms.Button btn_getir;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btn_listbox;
        private System.Windows.Forms.Button btn_dizi;
        private System.Windows.Forms.Button btn_liste;
    }
}