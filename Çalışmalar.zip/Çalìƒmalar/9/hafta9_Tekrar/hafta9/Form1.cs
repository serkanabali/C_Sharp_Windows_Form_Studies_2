﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;    //Sonradan eklenen kütüphane
using System.IO;                //Sonradan eklenen kütüphane

namespace hafta9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Global Değişken
        Random rastgele = new Random();
        int secim = -1;

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=vtYeni;Integrated Security=True";
        SqlConnection baglanti;

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 250;
            timer1.Start();

            comboBox1.Text = "Seçim Yapınız";
            comboBox1.Items.Add("button");
            comboBox1.Items.Add("Label");
            comboBox1.Items.Add("ListBox");
            comboBox1.Items.Add("TextBox");

            baglanti = new SqlConnection(baglantiDizesi);

            listBox1.HorizontalScrollbar = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (listBox2.Items.Count == 10)
            {
                timer1.Stop();
            }
            else
            {
                listBox2.Items.Add(rastgele.Next(3, 101) * 5);  // 15-500 arası
            }

            // rastgele.Next()          -> 0 ile en büyük int arası sayı üretir
            // rastgele.Next(101)       -> 0-101 (101 dahil değil) arası
            // rastgele.Next(3, 101)    -> 3-101 (101 dahil değil) arası
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            secim = comboBox1.SelectedIndex;
        }

        private void btn_kaydet1_Click(object sender, EventArgs e)
        {

        }

        private void btn_renk_Click(object sender, EventArgs e)
        {
            DialogResult tiklananTus = colorDialog1.ShowDialog();

            if (tiklananTus == DialogResult.OK)
            {
                switch (secim)
                {
                    case 0:
                        //button
                        foreach (Control eleman in this.Controls) // collection (this.constrols): 1 den fazla değer içeren veri türü
                        {
                            if ((eleman is Button) == true)
                            {
                                eleman.BackColor = colorDialog1.Color;
                            }
                        }

                        break;
                    case 1:
                        //label
                        foreach (Control eleman in this.Controls)
                        {
                            if ((eleman is Label) == true)
                            {
                                eleman.BackColor = colorDialog1.Color;
                            }
                        }
                        break;
                    case 2:
                        //listbox
                        foreach (Control eleman in this.Controls)
                        {
                            if ((eleman is ListBox) == true)
                            {
                                eleman.BackColor = colorDialog1.Color;
                            }
                        }
                        break;
                    case 3:
                        //textbox
                        foreach (Control eleman in this.Controls)
                        {
                            if ((eleman is TextBox) == true)
                            {
                                eleman.BackColor = colorDialog1.Color;
                            }
                        }
                        break;
                    default:
                        MessageBox.Show("Herhangi bir seçim yapılmadı");
                        break;
                }
            }

            if (tiklananTus == DialogResult.Cancel)
            {
                listBox1.Items.Add("Diyalog iptal edildi");
            }
        }

        private void btn_listele_Click(object sender, EventArgs e)
        {
            string komut = "select * from veriler";
            SqlDataAdapter kopru = new SqlDataAdapter(komut, baglanti);

            DataTable tablo = new DataTable();

            kopru.Fill(tablo);

            dataGridView1.DataSource = tablo;
        }

        private void btn_kaydet2_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;

            komut.CommandText = "insert into veriler(isim, adres) values(@ad, @adres)";
            komut.Parameters.AddWithValue("@ad", txt_isim.Text);
            komut.Parameters.AddWithValue("@adres", txt_adres.Text);

            komut.ExecuteNonQuery();

            baglanti.Close();
        }

        private void btn_ac_Click(object sender, EventArgs e)
        {

        }

        private void btn_yol_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                /*
                string[] klasorYolu = Directory.GetDirectories(folderBrowserDialog1.SelectedPath);
                foreach (string item in klasorYolu)
                {
                    listBox1.Items.Add(item);
                }
                */
                string[] dosyaYolu = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
                foreach (string item in dosyaYolu)
                {
                    //listBox1.Items.Add(item);

                    //listBox1.Items.Add(Path.GetFullPath(item));
                    //listBox1.Items.Add(Path.GetFullPath("C:/Deneme////123"));     //?dene?

                    //listBox1.Items.Add(Path.GetDirectoryName(item));

                    //listBox1.Items.Add(Path.GetFileName(item));

                    //listBox1.Items.Add(Path.GetFileNameWithoutExtension(item));

                    listBox1.Items.Add(Path.GetExtension(item));
                }
            }
        }
    }
}
