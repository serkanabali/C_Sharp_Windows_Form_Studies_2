﻿namespace hafta9
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.txt_isim = new System.Windows.Forms.TextBox();
            this.txt_adres = new System.Windows.Forms.TextBox();
            this.btn_renk = new System.Windows.Forms.Button();
            this.btn_font = new System.Windows.Forms.Button();
            this.btn_kaydet1 = new System.Windows.Forms.Button();
            this.btn_ac = new System.Windows.Forms.Button();
            this.btn_yol = new System.Windows.Forms.Button();
            this.btn_listele = new System.Windows.Forms.Button();
            this.btn_kaydet2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vtYeniDataSet = new hafta9.vtYeniDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vtYeniDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(209, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "İSİM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "ADRES";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 196);
            this.listBox1.TabIndex = 2;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(12, 242);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 196);
            this.listBox2.TabIndex = 3;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // txt_isim
            // 
            this.txt_isim.Location = new System.Drawing.Point(272, 69);
            this.txt_isim.Name = "txt_isim";
            this.txt_isim.Size = new System.Drawing.Size(100, 22);
            this.txt_isim.TabIndex = 4;
            // 
            // txt_adres
            // 
            this.txt_adres.Location = new System.Drawing.Point(272, 97);
            this.txt_adres.Name = "txt_adres";
            this.txt_adres.Size = new System.Drawing.Size(100, 22);
            this.txt_adres.TabIndex = 5;
            // 
            // btn_renk
            // 
            this.btn_renk.Location = new System.Drawing.Point(199, 398);
            this.btn_renk.Name = "btn_renk";
            this.btn_renk.Size = new System.Drawing.Size(113, 40);
            this.btn_renk.TabIndex = 6;
            this.btn_renk.Text = "RENK";
            this.btn_renk.UseVisualStyleBackColor = true;
            this.btn_renk.Click += new System.EventHandler(this.btn_renk_Click);
            // 
            // btn_font
            // 
            this.btn_font.Location = new System.Drawing.Point(318, 398);
            this.btn_font.Name = "btn_font";
            this.btn_font.Size = new System.Drawing.Size(113, 40);
            this.btn_font.TabIndex = 7;
            this.btn_font.Text = "FONT";
            this.btn_font.UseVisualStyleBackColor = true;
            // 
            // btn_kaydet1
            // 
            this.btn_kaydet1.Location = new System.Drawing.Point(437, 398);
            this.btn_kaydet1.Name = "btn_kaydet1";
            this.btn_kaydet1.Size = new System.Drawing.Size(113, 40);
            this.btn_kaydet1.TabIndex = 8;
            this.btn_kaydet1.Text = "KAYDET";
            this.btn_kaydet1.UseVisualStyleBackColor = true;
            this.btn_kaydet1.Click += new System.EventHandler(this.btn_kaydet1_Click);
            // 
            // btn_ac
            // 
            this.btn_ac.Location = new System.Drawing.Point(556, 398);
            this.btn_ac.Name = "btn_ac";
            this.btn_ac.Size = new System.Drawing.Size(113, 40);
            this.btn_ac.TabIndex = 9;
            this.btn_ac.Text = "AÇ";
            this.btn_ac.UseVisualStyleBackColor = true;
            this.btn_ac.Click += new System.EventHandler(this.btn_ac_Click);
            // 
            // btn_yol
            // 
            this.btn_yol.Location = new System.Drawing.Point(675, 398);
            this.btn_yol.Name = "btn_yol";
            this.btn_yol.Size = new System.Drawing.Size(113, 40);
            this.btn_yol.TabIndex = 10;
            this.btn_yol.Text = "KLASÖR YOLU";
            this.btn_yol.UseVisualStyleBackColor = true;
            this.btn_yol.Click += new System.EventHandler(this.btn_yol_Click);
            // 
            // btn_listele
            // 
            this.btn_listele.Location = new System.Drawing.Point(459, 242);
            this.btn_listele.Name = "btn_listele";
            this.btn_listele.Size = new System.Drawing.Size(113, 40);
            this.btn_listele.TabIndex = 11;
            this.btn_listele.Text = "LİSTELE";
            this.btn_listele.UseVisualStyleBackColor = true;
            this.btn_listele.Click += new System.EventHandler(this.btn_listele_Click);
            // 
            // btn_kaydet2
            // 
            this.btn_kaydet2.Location = new System.Drawing.Point(675, 242);
            this.btn_kaydet2.Name = "btn_kaydet2";
            this.btn_kaydet2.Size = new System.Drawing.Size(113, 40);
            this.btn_kaydet2.TabIndex = 12;
            this.btn_kaydet2.Text = "KAYDET";
            this.btn_kaydet2.UseVisualStyleBackColor = true;
            this.btn_kaydet2.Click += new System.EventHandler(this.btn_kaydet2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(459, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(329, 219);
            this.dataGridView1.TabIndex = 13;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(251, 242);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this.vtYeniDataSet;
            this.bindingSource1.Position = 0;
            // 
            // vtYeniDataSet
            // 
            this.vtYeniDataSet.DataSetName = "vtYeniDataSet";
            this.vtYeniDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_kaydet2);
            this.Controls.Add(this.btn_listele);
            this.Controls.Add(this.btn_yol);
            this.Controls.Add(this.btn_ac);
            this.Controls.Add(this.btn_kaydet1);
            this.Controls.Add(this.btn_font);
            this.Controls.Add(this.btn_renk);
            this.Controls.Add(this.txt_adres);
            this.Controls.Add(this.txt_isim);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vtYeniDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox txt_isim;
        private System.Windows.Forms.TextBox txt_adres;
        private System.Windows.Forms.Button btn_renk;
        private System.Windows.Forms.Button btn_font;
        private System.Windows.Forms.Button btn_kaydet1;
        private System.Windows.Forms.Button btn_ac;
        private System.Windows.Forms.Button btn_yol;
        private System.Windows.Forms.Button btn_listele;
        private System.Windows.Forms.Button btn_kaydet2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private vtYeniDataSet vtYeniDataSet;
    }
}

