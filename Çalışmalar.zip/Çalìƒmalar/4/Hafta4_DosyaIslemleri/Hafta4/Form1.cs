﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sonradan eklenen kütüphane

using System.IO;
using System.Media;

using WMPLib;   //Görsel olmadan        WMP kodlarının kullanılmasını sağlar
using AxWMPLib; //Görsel öğe şeklinde   WMP kodlarının kullanılmasını sağlar

namespace Hafta4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Image resim;
        SoundPlayer ses;

        private void Form1_Load(object sender, EventArgs e)
        {
            lst_dosyalar.HorizontalScrollbar = true;

            pb_normal.BackColor = Color.White;
            pb_image.BackColor = Color.White;

            pb_normal.ImageLocation = "..\\giphy.gif";
            pb_normal.SizeMode = PictureBoxSizeMode.Zoom;

            resim = Image.FromFile("Jack.jpg");
            pb_image.Image = resim;

            pb_image.SizeMode = PictureBoxSizeMode.StretchImage;

            checkBox1.Checked = true;

            ses = new SoundPlayer();
            //Müzikler klasöründekileri listbox'a ekleme
            string[] muzikler = Directory.GetFiles("Müzikler");

            foreach (string muzik in muzikler)
            {
                lst_dosyalar.Items.Add(Path.GetFileName(muzik));
            }
        }

        //------------Dosya - Klasör İşlemleri------------------------

        private void btn_klasorGoster_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                string dosyalarinYolu = folderBrowserDialog1.SelectedPath;
                string[] dosyalar = Directory.GetFiles(dosyalarinYolu);

                foreach (string eleman in dosyalar)
                {
                    lst_dosyalar.Items.Add(eleman);
                }
            }
        }

        private void btn_dosyaAc_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Metin Dosyaları|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string dosyaYolu = openFileDialog1.FileName;

                StreamReader okuyucu = new StreamReader(dosyaYolu);

                string dosyaYazisi = okuyucu.ReadToEnd();
                txt_metin.Text = dosyaYazisi;
            }
        }

        private void btn_dosyaKaydet_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = "Belge.txt";
            saveFileDialog1.Filter = "Metin DOsyaları|*.txt";
            saveFileDialog1.AddExtension = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string dosyaYolu = saveFileDialog1.FileName;

                using (StreamWriter yazici = new StreamWriter(dosyaYolu))
                {
                    yazici.WriteLine(txt_metin.Text);
                }
                /*
                //  Alternatif kullanım
                StreamWriter yazici = new StreamWriter(dosyaYolu)
                yazici.WriteLine(txt_metin.Text);

                yazici.Close();
                yazici.Dispose();
                */
            }
        }

        private void btn_kOlustur_Click(object sender, EventArgs e)
        {
            string dosyaKlasorAdi = txt_isim.Text;
            Directory.CreateDirectory(dosyaKlasorAdi);
        }

        private void btn_kSil_Click(object sender, EventArgs e)
        {
            string dosyaKlasorAdi = txt_isim.Text;
            Directory.Delete(dosyaKlasorAdi, true);
            //2. parametre true olursa klasor dolu olduğunda silme işlemi gerçekleşir.
        }

        private void btn_yol_Click(object sender, EventArgs e)
        {
            txt_isim.Text = Directory.GetCurrentDirectory();
        }

        private void btn_dOlustur_Click(object sender, EventArgs e)
        {
            string dosyaKlasorAdi = txt_isim.Text;
            using (File.Create(dosyaKlasorAdi)) ;
        }

        private void btn_dSil_Click(object sender, EventArgs e)
        {
            string dosyaKlasorAdi = txt_isim.Text;
            File.Delete(dosyaKlasorAdi);
        }

        //----------------------Resim İşlemleri---------------------------

        private void btn_sol_Click(object sender, EventArgs e)
        {
            resim.RotateFlip(RotateFlipType.Rotate270FlipNone);
            pb_image.Image = resim;
        }

        private void btn_sag_Click(object sender, EventArgs e)
        {
            resim.RotateFlip(RotateFlipType.Rotate90FlipNone);
            pb_image.Image = resim;
        }

        private void btn_yCevir_Click(object sender, EventArgs e)
        {
            resim.RotateFlip(RotateFlipType.RotateNoneFlipY);
            pb_image.Image = resim;
        }

        private void btn_xCevir_Click(object sender, EventArgs e)
        {
            resim.RotateFlip(RotateFlipType.RotateNoneFlipX);
            pb_image.Image = resim;
        }

        private void btn_resimKaydet_Click(object sender, EventArgs e)
        {
            Directory.GetCurrentDirectory();
            resim.Save("Jack.jpg");
        }

        //---------------------Müzik İşlemleri--------------
        private void lst_dosyalar_SelectedIndexChanged(object sender, EventArgs e)
        {
            string muzik = lst_dosyalar.SelectedItem.ToString();
            axWindowsMediaPlayer1.URL = "Müzikler\\" + muzik;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                axWindowsMediaPlayer1.Ctlenabled = true;
            }
            else
            {
                axWindowsMediaPlayer1.Ctlenabled = false;
            }
        }

        //---------------Video İşlemleri--------------------

        private void btn_medyaAc_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Müzik Dosyaları|*.mp3;*.mav|Film Dosyaları|*.mp4";
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = openFileDialog1.FileName;
            }
        }

        //Ses sadece .mav uzantılı ise açılır
        private void btn_sesAc_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Ses Dosyaları|*.wav";
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ses.SoundLocation = openFileDialog1.FileName;
                label1.Text = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
            }
        }

        private void btn_baslat_Click(object sender, EventArgs e)
        {
            ses.Play();
        }

        private void btn_durdur_Click(object sender, EventArgs e)
        {
            ses.Stop();
        }

        private void btn_tekrarliBaslat_Click(object sender, EventArgs e)
        {
            ses.PlayLooping();
        }
    }
}
