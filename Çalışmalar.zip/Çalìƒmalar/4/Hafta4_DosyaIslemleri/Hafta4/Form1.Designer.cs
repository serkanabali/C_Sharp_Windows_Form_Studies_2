﻿namespace Hafta4
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_dosyaKaydet = new System.Windows.Forms.Button();
            this.btn_dosyaAc = new System.Windows.Forms.Button();
            this.lst_dosyalar = new System.Windows.Forms.ListBox();
            this.txt_metin = new System.Windows.Forms.TextBox();
            this.btn_klasorGoster = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.txt_isim = new System.Windows.Forms.TextBox();
            this.btn_kOlustur = new System.Windows.Forms.Button();
            this.btn_kSil = new System.Windows.Forms.Button();
            this.btn_dOlustur = new System.Windows.Forms.Button();
            this.btn_dSil = new System.Windows.Forms.Button();
            this.btn_yol = new System.Windows.Forms.Button();
            this.pb_normal = new System.Windows.Forms.PictureBox();
            this.pb_image = new System.Windows.Forms.PictureBox();
            this.btn_sol = new System.Windows.Forms.Button();
            this.btn_sag = new System.Windows.Forms.Button();
            this.btn_yCevir = new System.Windows.Forms.Button();
            this.btn_xCevir = new System.Windows.Forms.Button();
            this.btn_resimKaydet = new System.Windows.Forms.Button();
            this.btn_medyaAc = new System.Windows.Forms.Button();
            this.btn_sesAc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btn_baslat = new System.Windows.Forms.Button();
            this.btn_durdur = new System.Windows.Forms.Button();
            this.btn_tekrarliBaslat = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.pb_normal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_dosyaKaydet
            // 
            this.btn_dosyaKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dosyaKaydet.Location = new System.Drawing.Point(155, 92);
            this.btn_dosyaKaydet.Name = "btn_dosyaKaydet";
            this.btn_dosyaKaydet.Size = new System.Drawing.Size(158, 34);
            this.btn_dosyaKaydet.TabIndex = 2;
            this.btn_dosyaKaydet.Text = "Dosya Kaydet";
            this.btn_dosyaKaydet.UseVisualStyleBackColor = true;
            this.btn_dosyaKaydet.Click += new System.EventHandler(this.btn_dosyaKaydet_Click);
            // 
            // btn_dosyaAc
            // 
            this.btn_dosyaAc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dosyaAc.Location = new System.Drawing.Point(155, 52);
            this.btn_dosyaAc.Name = "btn_dosyaAc";
            this.btn_dosyaAc.Size = new System.Drawing.Size(158, 34);
            this.btn_dosyaAc.TabIndex = 1;
            this.btn_dosyaAc.Text = "Dosya Aç";
            this.btn_dosyaAc.UseVisualStyleBackColor = true;
            this.btn_dosyaAc.Click += new System.EventHandler(this.btn_dosyaAc_Click);
            // 
            // lst_dosyalar
            // 
            this.lst_dosyalar.FormattingEnabled = true;
            this.lst_dosyalar.ItemHeight = 16;
            this.lst_dosyalar.Location = new System.Drawing.Point(12, 12);
            this.lst_dosyalar.Name = "lst_dosyalar";
            this.lst_dosyalar.Size = new System.Drawing.Size(137, 132);
            this.lst_dosyalar.TabIndex = 3;
            this.lst_dosyalar.SelectedIndexChanged += new System.EventHandler(this.lst_dosyalar_SelectedIndexChanged);
            // 
            // txt_metin
            // 
            this.txt_metin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_metin.Location = new System.Drawing.Point(12, 400);
            this.txt_metin.Multiline = true;
            this.txt_metin.Name = "txt_metin";
            this.txt_metin.Size = new System.Drawing.Size(137, 132);
            this.txt_metin.TabIndex = 4;
            // 
            // btn_klasorGoster
            // 
            this.btn_klasorGoster.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_klasorGoster.Location = new System.Drawing.Point(155, 12);
            this.btn_klasorGoster.Name = "btn_klasorGoster";
            this.btn_klasorGoster.Size = new System.Drawing.Size(158, 34);
            this.btn_klasorGoster.TabIndex = 0;
            this.btn_klasorGoster.Text = "Klasör Göster";
            this.btn_klasorGoster.UseVisualStyleBackColor = true;
            this.btn_klasorGoster.Click += new System.EventHandler(this.btn_klasorGoster_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txt_isim
            // 
            this.txt_isim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_isim.Location = new System.Drawing.Point(155, 132);
            this.txt_isim.Name = "txt_isim";
            this.txt_isim.Size = new System.Drawing.Size(153, 26);
            this.txt_isim.TabIndex = 5;
            // 
            // btn_kOlustur
            // 
            this.btn_kOlustur.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kOlustur.Location = new System.Drawing.Point(155, 400);
            this.btn_kOlustur.Name = "btn_kOlustur";
            this.btn_kOlustur.Size = new System.Drawing.Size(153, 30);
            this.btn_kOlustur.TabIndex = 6;
            this.btn_kOlustur.Text = "Klasör Oluştur";
            this.btn_kOlustur.UseVisualStyleBackColor = true;
            this.btn_kOlustur.Click += new System.EventHandler(this.btn_kOlustur_Click);
            // 
            // btn_kSil
            // 
            this.btn_kSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kSil.Location = new System.Drawing.Point(155, 436);
            this.btn_kSil.Name = "btn_kSil";
            this.btn_kSil.Size = new System.Drawing.Size(153, 30);
            this.btn_kSil.TabIndex = 7;
            this.btn_kSil.Text = "Klasör Sil";
            this.btn_kSil.UseVisualStyleBackColor = true;
            this.btn_kSil.Click += new System.EventHandler(this.btn_kSil_Click);
            // 
            // btn_dOlustur
            // 
            this.btn_dOlustur.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dOlustur.Location = new System.Drawing.Point(155, 472);
            this.btn_dOlustur.Name = "btn_dOlustur";
            this.btn_dOlustur.Size = new System.Drawing.Size(153, 30);
            this.btn_dOlustur.TabIndex = 8;
            this.btn_dOlustur.Text = "Dosya Oluştur";
            this.btn_dOlustur.UseVisualStyleBackColor = true;
            this.btn_dOlustur.Click += new System.EventHandler(this.btn_dOlustur_Click);
            // 
            // btn_dSil
            // 
            this.btn_dSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dSil.Location = new System.Drawing.Point(155, 508);
            this.btn_dSil.Name = "btn_dSil";
            this.btn_dSil.Size = new System.Drawing.Size(153, 30);
            this.btn_dSil.TabIndex = 9;
            this.btn_dSil.Text = "Dosya Sil";
            this.btn_dSil.UseVisualStyleBackColor = true;
            this.btn_dSil.Click += new System.EventHandler(this.btn_dSil_Click);
            // 
            // btn_yol
            // 
            this.btn_yol.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_yol.Location = new System.Drawing.Point(155, 544);
            this.btn_yol.Name = "btn_yol";
            this.btn_yol.Size = new System.Drawing.Size(153, 30);
            this.btn_yol.TabIndex = 10;
            this.btn_yol.Text = "Aktif Yol";
            this.btn_yol.UseVisualStyleBackColor = true;
            this.btn_yol.Click += new System.EventHandler(this.btn_yol_Click);
            // 
            // pb_normal
            // 
            this.pb_normal.Location = new System.Drawing.Point(265, 220);
            this.pb_normal.Name = "pb_normal";
            this.pb_normal.Size = new System.Drawing.Size(194, 114);
            this.pb_normal.TabIndex = 11;
            this.pb_normal.TabStop = false;
            // 
            // pb_image
            // 
            this.pb_image.Location = new System.Drawing.Point(577, 12);
            this.pb_image.Name = "pb_image";
            this.pb_image.Size = new System.Drawing.Size(268, 142);
            this.pb_image.TabIndex = 12;
            this.pb_image.TabStop = false;
            // 
            // btn_sol
            // 
            this.btn_sol.Location = new System.Drawing.Point(464, 79);
            this.btn_sol.Name = "btn_sol";
            this.btn_sol.Size = new System.Drawing.Size(107, 34);
            this.btn_sol.TabIndex = 13;
            this.btn_sol.Text = "Sola Döndür";
            this.btn_sol.UseVisualStyleBackColor = true;
            this.btn_sol.Click += new System.EventHandler(this.btn_sol_Click);
            // 
            // btn_sag
            // 
            this.btn_sag.Location = new System.Drawing.Point(464, 39);
            this.btn_sag.Name = "btn_sag";
            this.btn_sag.Size = new System.Drawing.Size(107, 34);
            this.btn_sag.TabIndex = 14;
            this.btn_sag.Text = "Sağa Döndür";
            this.btn_sag.UseVisualStyleBackColor = true;
            this.btn_sag.Click += new System.EventHandler(this.btn_sag_Click);
            // 
            // btn_yCevir
            // 
            this.btn_yCevir.Location = new System.Drawing.Point(851, 39);
            this.btn_yCevir.Name = "btn_yCevir";
            this.btn_yCevir.Size = new System.Drawing.Size(107, 34);
            this.btn_yCevir.TabIndex = 15;
            this.btn_yCevir.Text = "Dikey Çevir";
            this.btn_yCevir.UseVisualStyleBackColor = true;
            this.btn_yCevir.Click += new System.EventHandler(this.btn_yCevir_Click);
            // 
            // btn_xCevir
            // 
            this.btn_xCevir.Location = new System.Drawing.Point(851, 79);
            this.btn_xCevir.Name = "btn_xCevir";
            this.btn_xCevir.Size = new System.Drawing.Size(107, 34);
            this.btn_xCevir.TabIndex = 16;
            this.btn_xCevir.Text = "Yatay Çevir";
            this.btn_xCevir.UseVisualStyleBackColor = true;
            this.btn_xCevir.Click += new System.EventHandler(this.btn_xCevir_Click);
            // 
            // btn_resimKaydet
            // 
            this.btn_resimKaydet.Location = new System.Drawing.Point(653, 160);
            this.btn_resimKaydet.Name = "btn_resimKaydet";
            this.btn_resimKaydet.Size = new System.Drawing.Size(107, 34);
            this.btn_resimKaydet.TabIndex = 17;
            this.btn_resimKaydet.Text = "Resim Kaydet";
            this.btn_resimKaydet.UseVisualStyleBackColor = true;
            this.btn_resimKaydet.Click += new System.EventHandler(this.btn_resimKaydet_Click);
            // 
            // btn_medyaAc
            // 
            this.btn_medyaAc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_medyaAc.Location = new System.Drawing.Point(552, 475);
            this.btn_medyaAc.Name = "btn_medyaAc";
            this.btn_medyaAc.Size = new System.Drawing.Size(85, 66);
            this.btn_medyaAc.TabIndex = 18;
            this.btn_medyaAc.Text = "Medya Aç";
            this.btn_medyaAc.UseVisualStyleBackColor = true;
            this.btn_medyaAc.Click += new System.EventHandler(this.btn_medyaAc_Click);
            // 
            // btn_sesAc
            // 
            this.btn_sesAc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sesAc.Location = new System.Drawing.Point(722, 515);
            this.btn_sesAc.Name = "btn_sesAc";
            this.btn_sesAc.Size = new System.Drawing.Size(107, 34);
            this.btn_sesAc.TabIndex = 20;
            this.btn_sesAc.Text = "Ses Aç";
            this.btn_sesAc.UseVisualStyleBackColor = true;
            this.btn_sesAc.Click += new System.EventHandler(this.btn_sesAc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(556, 545);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 29);
            this.label1.TabIndex = 23;
            this.label1.Text = "label1";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(904, 554);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 20);
            this.checkBox1.TabIndex = 24;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btn_baslat
            // 
            this.btn_baslat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_baslat.Location = new System.Drawing.Point(666, 475);
            this.btn_baslat.Name = "btn_baslat";
            this.btn_baslat.Size = new System.Drawing.Size(107, 34);
            this.btn_baslat.TabIndex = 25;
            this.btn_baslat.Text = "Başlat";
            this.btn_baslat.UseVisualStyleBackColor = true;
            this.btn_baslat.Click += new System.EventHandler(this.btn_baslat_Click);
            // 
            // btn_durdur
            // 
            this.btn_durdur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_durdur.Location = new System.Drawing.Point(779, 475);
            this.btn_durdur.Name = "btn_durdur";
            this.btn_durdur.Size = new System.Drawing.Size(107, 34);
            this.btn_durdur.TabIndex = 26;
            this.btn_durdur.Text = "Durdur";
            this.btn_durdur.UseVisualStyleBackColor = true;
            this.btn_durdur.Click += new System.EventHandler(this.btn_durdur_Click);
            // 
            // btn_tekrarliBaslat
            // 
            this.btn_tekrarliBaslat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_tekrarliBaslat.Location = new System.Drawing.Point(904, 475);
            this.btn_tekrarliBaslat.Name = "btn_tekrarliBaslat";
            this.btn_tekrarliBaslat.Size = new System.Drawing.Size(97, 73);
            this.btn_tekrarliBaslat.TabIndex = 27;
            this.btn_tekrarliBaslat.Text = "Tekrarlı Başlat";
            this.btn_tekrarliBaslat.UseVisualStyleBackColor = true;
            this.btn_tekrarliBaslat.Click += new System.EventHandler(this.btn_tekrarliBaslat_Click);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(552, 220);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(447, 249);
            this.axWindowsMediaPlayer1.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1048, 597);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Controls.Add(this.btn_tekrarliBaslat);
            this.Controls.Add(this.btn_durdur);
            this.Controls.Add(this.btn_baslat);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_sesAc);
            this.Controls.Add(this.btn_medyaAc);
            this.Controls.Add(this.btn_resimKaydet);
            this.Controls.Add(this.btn_xCevir);
            this.Controls.Add(this.btn_yCevir);
            this.Controls.Add(this.btn_sag);
            this.Controls.Add(this.btn_sol);
            this.Controls.Add(this.pb_image);
            this.Controls.Add(this.pb_normal);
            this.Controls.Add(this.btn_yol);
            this.Controls.Add(this.btn_dSil);
            this.Controls.Add(this.btn_dOlustur);
            this.Controls.Add(this.btn_kSil);
            this.Controls.Add(this.btn_kOlustur);
            this.Controls.Add(this.txt_isim);
            this.Controls.Add(this.btn_klasorGoster);
            this.Controls.Add(this.txt_metin);
            this.Controls.Add(this.lst_dosyalar);
            this.Controls.Add(this.btn_dosyaAc);
            this.Controls.Add(this.btn_dosyaKaydet);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_normal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_dosyaKaydet;
        private System.Windows.Forms.Button btn_dosyaAc;
        private System.Windows.Forms.ListBox lst_dosyalar;
        private System.Windows.Forms.TextBox txt_metin;
        private System.Windows.Forms.Button btn_klasorGoster;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox txt_isim;
        private System.Windows.Forms.Button btn_kOlustur;
        private System.Windows.Forms.Button btn_kSil;
        private System.Windows.Forms.Button btn_dOlustur;
        private System.Windows.Forms.Button btn_dSil;
        private System.Windows.Forms.Button btn_yol;
        private System.Windows.Forms.PictureBox pb_normal;
        private System.Windows.Forms.PictureBox pb_image;
        private System.Windows.Forms.Button btn_sol;
        private System.Windows.Forms.Button btn_sag;
        private System.Windows.Forms.Button btn_yCevir;
        private System.Windows.Forms.Button btn_xCevir;
        private System.Windows.Forms.Button btn_resimKaydet;
        private System.Windows.Forms.Button btn_medyaAc;
        private System.Windows.Forms.Button btn_sesAc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btn_baslat;
        private System.Windows.Forms.Button btn_durdur;
        private System.Windows.Forms.Button btn_tekrarliBaslat;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
    }
}

