﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;    //eklendi
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hafta7
{
    public partial class Ana_Menu : Form
    {
        public Ana_Menu()
        {
            InitializeComponent();
        }

        private void Ana_Menu_Load(object sender, EventArgs e)
        {
            /*
            Giris f = new Giris();
            f.ShowDialog();
            this.Hide();
            */

            lbl_uygulamaYolu.Text = Directory.GetCurrentDirectory();
        }

        //A
        private void button1_Click(object sender, EventArgs e)
        {
            string yol = "..\\..\\Resimler\\CarlCheo.png";

            lbl_duzMetin.Text = yol;
            lbl_uygulamaYolu.Text = Path.GetFullPath(yol);  //dosya yolu alındı
        }

        //B
        private void button2_Click(object sender, EventArgs e)
        {

        }

        //C
        private void button3_Click(object sender, EventArgs e)
        {
            string yol = "\\Resimler/CarlCheo.png";
            lbl_duzMetin.Text = yol;
            lbl_yeniYol.Text = Path.GetFullPath(yol);
        }

        //D
        private void button4_Click(object sender, EventArgs e)
        {

        }

        //E
        private void button5_Click(object sender, EventArgs e)
        {
            //HATA
            /*
            string yol = txt_adres.Text;
            lbl_duzMetin.Text = yol;
            lbl_yeniYol.Text = Path.GetFullPath(yol);
            */
        }
    }
}
