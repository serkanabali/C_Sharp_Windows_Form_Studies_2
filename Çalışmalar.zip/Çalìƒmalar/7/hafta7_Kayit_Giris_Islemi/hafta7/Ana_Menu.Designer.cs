﻿namespace hafta7
{
    partial class Ana_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_uygulamaYolu = new System.Windows.Forms.Label();
            this.lbl_yeniYol = new System.Windows.Forms.Label();
            this.lbl_duzMetin = new System.Windows.Forms.Label();
            this.txt_adres = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_uygulamaYolu
            // 
            this.lbl_uygulamaYolu.AutoSize = true;
            this.lbl_uygulamaYolu.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_uygulamaYolu.Location = new System.Drawing.Point(12, 9);
            this.lbl_uygulamaYolu.Name = "lbl_uygulamaYolu";
            this.lbl_uygulamaYolu.Size = new System.Drawing.Size(197, 31);
            this.lbl_uygulamaYolu.TabIndex = 0;
            this.lbl_uygulamaYolu.Text = "Uygulama Yolu";
            // 
            // lbl_yeniYol
            // 
            this.lbl_yeniYol.AutoSize = true;
            this.lbl_yeniYol.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_yeniYol.Location = new System.Drawing.Point(12, 40);
            this.lbl_yeniYol.Name = "lbl_yeniYol";
            this.lbl_yeniYol.Size = new System.Drawing.Size(114, 31);
            this.lbl_yeniYol.TabIndex = 1;
            this.lbl_yeniYol.Text = "Yeni Yol";
            // 
            // lbl_duzMetin
            // 
            this.lbl_duzMetin.AutoSize = true;
            this.lbl_duzMetin.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_duzMetin.Location = new System.Drawing.Point(12, 71);
            this.lbl_duzMetin.Name = "lbl_duzMetin";
            this.lbl_duzMetin.Size = new System.Drawing.Size(136, 31);
            this.lbl_duzMetin.TabIndex = 2;
            this.lbl_duzMetin.Text = "Düz Metin";
            // 
            // txt_adres
            // 
            this.txt_adres.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_adres.Location = new System.Drawing.Point(12, 105);
            this.txt_adres.Name = "txt_adres";
            this.txt_adres.Size = new System.Drawing.Size(464, 38);
            this.txt_adres.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(12, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 71);
            this.button1.TabIndex = 4;
            this.button1.Text = "A";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(106, 149);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 71);
            this.button2.TabIndex = 5;
            this.button2.Text = "B";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(200, 149);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 71);
            this.button3.TabIndex = 6;
            this.button3.Text = "C";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.Location = new System.Drawing.Point(294, 149);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 71);
            this.button4.TabIndex = 7;
            this.button4.Text = "D";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.Location = new System.Drawing.Point(388, 149);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 71);
            this.button5.TabIndex = 8;
            this.button5.Text = "E";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Ana_Menu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_adres);
            this.Controls.Add(this.lbl_duzMetin);
            this.Controls.Add(this.lbl_yeniYol);
            this.Controls.Add(this.lbl_uygulamaYolu);
            this.Name = "Ana_Menu";
            this.Text = "Ana_Menu";
            this.Load += new System.EventHandler(this.Ana_Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_uygulamaYolu;
        private System.Windows.Forms.Label lbl_yeniYol;
        private System.Windows.Forms.Label lbl_duzMetin;
        private System.Windows.Forms.TextBox txt_adres;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}