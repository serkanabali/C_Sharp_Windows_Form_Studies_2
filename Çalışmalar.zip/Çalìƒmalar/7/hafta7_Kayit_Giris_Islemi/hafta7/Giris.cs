﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hafta7
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog = vtDeneme; Integrated Security = True";
        SqlConnection baglanti;
        bool yetki = false;

        private void btn_girisKayit_Click(object sender, EventArgs e)
        {
            Kayit f = new Kayit();
            f.ShowDialog(); //işim bitince kapatacağım
        }

        private void Giris_Load(object sender, EventArgs e)
        {
            baglanti = new SqlConnection(baglantiDizesi);
            txt_sifre.PasswordChar = '*';
        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txt_sifre.Text)
                || String.IsNullOrWhiteSpace(txt_kullanici.Text))
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş bırakılamaz");
            }
            else
            {
                baglanti.Open();

                SqlCommand komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "select * from kullanicilar where kadi=@kullanici";
                komut.Parameters.AddWithValue("@kullanici", txt_kullanici.Text);

                SqlDataReader okuyucu = komut.ExecuteReader();
                
                //HasRows da olur; Read sonraki veriyi de okur
                if (okuyucu.Read() == true)
                {
                    if (okuyucu["kAdi"].ToString() == txt_kullanici.Text
                        && okuyucu["sifre"].ToString() == txt_sifre.Text)
                    {
                        yetki = true;
                        Application.OpenForms["Ana_Menu"].Show();   //açık olan form olmalı
                        this.Close();
                        /*
                        Ana_Menu f = new Ana_Menu();
                        f.Show();
                        this.Hide();
                        */
                    }
                    else
                    {
                        //Şifre yanlış olma ihtimali
                        MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                    }
                }
                else
                {
                    //Kullanıcı adı yanlış olma ihtimali
                    MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                }

                baglanti.Close();
            }
        }

        private void Giris_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (yetki == false)
            {
                Application.Exit();
            }
        }
    }
}
