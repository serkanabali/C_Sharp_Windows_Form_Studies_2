﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hafta7
{
    public partial class Kayit : Form
    {
        public Kayit()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog = vtDeneme; Integrated Security = True";

        SqlConnection baglanti;

        private void Kayit_Load(object sender, EventArgs e)
        {
            baglanti =new SqlConnection(baglantiDizesi);
            //pass sansürleme
            txt_kSifre.PasswordChar = '*';
            txt_kSifreTekrar.PasswordChar = '*';
        }

        private void btn_kayit_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txt_kAdi.Text) || String.IsNullOrWhiteSpace(txt_kSifre.Text))
            {
                MessageBox.Show("Kullanıcı adı veya şifre boş bırakılamaz.");
            }

            else if (txt_kSifre.Text.Equals(txt_kSifreTekrar.Text) == false)    //txt_kSifre.Text != txt_kSifreTekrar.Text
            {
                    MessageBox.Show("Şifreler aynı değil");
                }

            else
            {
                baglanti.Open();

                SqlCommand komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "INSERT INTO Kullanicilar VALUES(@kullaniciAdi,@sifre)";
                komut.Parameters.AddWithValue("@kullaniciAdi", txt_kAdi.Text);
                komut.Parameters.AddWithValue("@sifre", txt_kSifre.Text);

                komut.ExecuteNonQuery();
                MessageBox.Show("Kayıt Başarılı");

                baglanti.Close();
            }
        }
    }
}
