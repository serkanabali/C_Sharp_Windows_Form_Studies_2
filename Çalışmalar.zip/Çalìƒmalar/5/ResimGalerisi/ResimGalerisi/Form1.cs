﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;    //Sonradan eklenen kütüphaneler

namespace ResimGalerisi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] resimler = Directory.GetFiles("Resimler");
        int resimYeri = 0;
        Random rastgele = new Random();

        private void Form1_Load(object sender, EventArgs e)
        {
            flowLayoutPanel1.BorderStyle = BorderStyle.FixedSingle;
            pb_resim.BorderStyle = BorderStyle.Fixed3D;
            pb_resim.SizeMode = PictureBoxSizeMode.StretchImage;
            ResimEkle();
            ResimGuncelle();
        }
        
        private void ResimEkle()
        {
            for (int i = 0; i < resimler.Length; i++)
            {
                PictureBox pb = new PictureBox();
                pb.Size = new Size(75, 75);
                pb.ImageLocation = resimler[i];
                pb.SizeMode = PictureBoxSizeMode.StretchImage;
                pb.Tag = i;             //İleri, geri tuşunu düzeltmek için yapıldı
                pb.Click += Pb_Tiklama; //Pb_Click methodu oluşturdu

                flowLayoutPanel1.Controls.Add(pb);
            }
        }

        private void Pb_Tiklama(object sender, EventArgs e)
        {
            PictureBox tiklananResim = sender as PictureBox;
            pb_resim.Image = tiklananResim.Image;
            resimYeri = Convert.ToInt32(tiklananResim.Tag);
        }

        private void ResimGuncelle()
        {
            pb_resim.ImageLocation = resimler[resimYeri];
        }

        private void btn_enBas_Click(object sender, EventArgs e)
        {
            resimYeri = 0;
            ResimGuncelle();
        }

        private void btn_enSon_Click(object sender, EventArgs e)
        {
            resimYeri = resimler.Length-1;
            ResimGuncelle();
        }

        private void btn_ileri_Click(object sender, EventArgs e)
        {
            if (resimYeri == resimler.Length - 1)
            {
                resimYeri = 0;
            }
            else
            {
                resimYeri = resimYeri + 1;
            }
            ResimGuncelle();
        }

        private void btn_geri_Click(object sender, EventArgs e)
        {
            if (resimYeri == 0)
            {
                resimYeri = resimler.Length - 1;
            }
            else
            {
                resimYeri = resimYeri - 1;
            }
            /*
             * Alternatif
            resimYeri++;
            if (resimYeri < 0)
            {
                resimYeri = resimler.Length - 1;
            }
            */
            ResimGuncelle();
        }

        private void btn_rastgele_Click(object sender, EventArgs e)
        {
            do
            {
                int resimYeri2 = rastgele.Next(0, resimler.Length);
                if (resimYeri != resimYeri2)
                {
                    resimYeri = resimYeri2;
                    break;
                }
            } while (true);

            ResimGuncelle();
        }

        private void btn_slayt_Click(object sender, EventArgs e)
        {
            resimYeri = -1;
            timer1.Interval = 1000;
            timer1.Start();
            btn_slayt.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (resimYeri == resimler.Length - 1)
            {
                timer1.Stop();
                btn_slayt.Enabled = true;
            }
            else
            {
                resimYeri = resimYeri + 1;
            }
            ResimGuncelle();
        }
    }
}
