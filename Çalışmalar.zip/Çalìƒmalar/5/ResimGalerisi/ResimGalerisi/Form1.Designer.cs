﻿namespace ResimGalerisi
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pb_resim = new System.Windows.Forms.PictureBox();
            this.btn_enBas = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_geri = new System.Windows.Forms.Button();
            this.btn_slayt = new System.Windows.Forms.Button();
            this.btn_rastgele = new System.Windows.Forms.Button();
            this.btn_ileri = new System.Windows.Forms.Button();
            this.btn_enSon = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pb_resim)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_resim
            // 
            this.pb_resim.Location = new System.Drawing.Point(252, 13);
            this.pb_resim.Name = "pb_resim";
            this.pb_resim.Size = new System.Drawing.Size(684, 372);
            this.pb_resim.TabIndex = 0;
            this.pb_resim.TabStop = false;
            // 
            // btn_enBas
            // 
            this.btn_enBas.Location = new System.Drawing.Point(252, 391);
            this.btn_enBas.Name = "btn_enBas";
            this.btn_enBas.Size = new System.Drawing.Size(109, 39);
            this.btn_enBas.TabIndex = 1;
            this.btn_enBas.Text = "<<";
            this.btn_enBas.UseVisualStyleBackColor = true;
            this.btn_enBas.Click += new System.EventHandler(this.btn_enBas_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 13);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(234, 417);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // btn_geri
            // 
            this.btn_geri.Location = new System.Drawing.Point(367, 391);
            this.btn_geri.Name = "btn_geri";
            this.btn_geri.Size = new System.Drawing.Size(109, 39);
            this.btn_geri.TabIndex = 3;
            this.btn_geri.Text = "<";
            this.btn_geri.UseVisualStyleBackColor = true;
            this.btn_geri.Click += new System.EventHandler(this.btn_geri_Click);
            // 
            // btn_slayt
            // 
            this.btn_slayt.Location = new System.Drawing.Point(482, 391);
            this.btn_slayt.Name = "btn_slayt";
            this.btn_slayt.Size = new System.Drawing.Size(109, 39);
            this.btn_slayt.TabIndex = 4;
            this.btn_slayt.Text = "Slayt";
            this.btn_slayt.UseVisualStyleBackColor = true;
            this.btn_slayt.Click += new System.EventHandler(this.btn_slayt_Click);
            // 
            // btn_rastgele
            // 
            this.btn_rastgele.Location = new System.Drawing.Point(597, 391);
            this.btn_rastgele.Name = "btn_rastgele";
            this.btn_rastgele.Size = new System.Drawing.Size(109, 39);
            this.btn_rastgele.TabIndex = 5;
            this.btn_rastgele.Text = "Rastgele";
            this.btn_rastgele.UseVisualStyleBackColor = true;
            this.btn_rastgele.Click += new System.EventHandler(this.btn_rastgele_Click);
            // 
            // btn_ileri
            // 
            this.btn_ileri.Location = new System.Drawing.Point(712, 391);
            this.btn_ileri.Name = "btn_ileri";
            this.btn_ileri.Size = new System.Drawing.Size(109, 39);
            this.btn_ileri.TabIndex = 6;
            this.btn_ileri.Text = ">";
            this.btn_ileri.UseVisualStyleBackColor = true;
            this.btn_ileri.Click += new System.EventHandler(this.btn_ileri_Click);
            // 
            // btn_enSon
            // 
            this.btn_enSon.Location = new System.Drawing.Point(827, 392);
            this.btn_enSon.Name = "btn_enSon";
            this.btn_enSon.Size = new System.Drawing.Size(109, 39);
            this.btn_enSon.TabIndex = 7;
            this.btn_enSon.Text = ">>";
            this.btn_enSon.UseVisualStyleBackColor = true;
            this.btn_enSon.Click += new System.EventHandler(this.btn_enSon_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(953, 443);
            this.Controls.Add(this.btn_enSon);
            this.Controls.Add(this.btn_ileri);
            this.Controls.Add(this.btn_rastgele);
            this.Controls.Add(this.btn_slayt);
            this.Controls.Add(this.btn_geri);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btn_enBas);
            this.Controls.Add(this.pb_resim);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_resim)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_resim;
        private System.Windows.Forms.Button btn_enBas;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn_geri;
        private System.Windows.Forms.Button btn_slayt;
        private System.Windows.Forms.Button btn_rastgele;
        private System.Windows.Forms.Button btn_ileri;
        private System.Windows.Forms.Button btn_enSon;
        private System.Windows.Forms.Timer timer1;
    }
}

