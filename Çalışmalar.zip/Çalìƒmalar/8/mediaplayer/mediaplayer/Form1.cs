﻿//42.-46. satır aralarılığına bak
using AxWMPLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;    //Sonradan eklenen kütüphane
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mediaplayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] muziklistesi;
        int muzikyeri = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            axWMP.Dock = DockStyle.Fill;
            this.AutoScaleMode = AutoScaleMode.None;
            muziklistesi = Directory.GetFiles("Muzikler");

            foreach (string muzik in muziklistesi)
            {
                lst_muzikler.Items.Add(Path.GetFileNameWithoutExtension(muzik));
            }

            cb_wmpTuru.Items.Add("Tam Kontrol");
            cb_wmpTuru.Items.Add("Minimum Kontrol");
            cb_wmpTuru.Items.Add("Görünmez");
            cb_wmpTuru.Items.Add("Sıfır Kontrol");

            //WMP için araştırılabilecekler
            //ses artırma azaltma
            //ileri geri sarma, yalnızca videolar geri sarılabilir
            //çalışan medyanın anlık zamanı
            //çalışan medyanın toplam süresi
        }

        private void lst_muzikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            muzikyeri = lst_muzikler.SelectedIndex;
            axWMP.URL = muziklistesi[muzikyeri];
        }

        private void btn_ileri_Click(object sender, EventArgs e)
        {
            muzikyeri++;

            if (muzikyeri > muziklistesi.Length - 1)
            {
                muzikyeri = 0;
            }

            lst_muzikler.SelectedIndex = muzikyeri;
        }

        private void btn_geri_Click(object sender, EventArgs e)
        {
            muzikyeri--;

            if (muzikyeri < 0)
            {
                muzikyeri = muziklistesi.Length - 1;
            }
            
            lst_muzikler.SelectedIndex = muzikyeri;
        }
        
        private void btn_oynat_durdur_Click(object sender, EventArgs e)
        {
            if (axWMP.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                axWMP.Ctlcontrols.pause();
            }
            else
            {
                axWMP.Ctlcontrols.play();
            }
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.Multiselect = true;
            openFileDialog1.Filter = "Müzik Dosyaları | *.mp3";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string[] eklenenMuzikler = openFileDialog1.FileNames;

                foreach (string eleman in eklenenMuzikler)
                {
                    lst_muzikler.Items.Add(Path.GetFileNameWithoutExtension(eleman));   //Dizin yerine dosya ismi alır
                    //Diziyi yeniden boyutlandırma
                    Array.Resize(ref muziklistesi, muziklistesi.Length + 1);
                    muziklistesi[muziklistesi.Length - 1] = eleman;
                }
            }
        }

        private void cb_wmpTuru_SelectedIndexChanged(object sender, EventArgs e)
        {
            int seciliIndis = cb_wmpTuru.SelectedIndex;
            switch (seciliIndis)
            {
                case 0:
                    axWMP.uiMode = "full";
                    break;
                case 1:
                    axWMP.uiMode = "mini";
                    break;
                case 2:
                    axWMP.uiMode = "invisible";
                    break;
                case 3:
                    axWMP.uiMode = "none";
                    break;
            }
        }
    }
}
