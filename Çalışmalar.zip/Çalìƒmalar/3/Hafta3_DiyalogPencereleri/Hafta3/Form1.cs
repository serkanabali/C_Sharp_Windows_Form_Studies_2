﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hafta3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_renk_Click(object sender, EventArgs e)
        {
            colorDialog1.AllowFullOpen = false;
            colorDialog1.FullOpen = true;
            colorDialog1.ShowHelp = true;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                label1.Text= colorDialog1.Color.ToString();
                label1.ForeColor = colorDialog1.Color;
            }

            /*
            //Diyalogsuz Alternatif
            DialogResult mesaj = MessageBox.Show("Emin misiniz?", "Uyarı", MessageBoxButtons.YesNoCancel);
            if (mesaj == DialogResult.Yes)
            {
                label1.ForeColor = Color.Red;
            }
            */
        }

        private void btn_font_Click(object sender, EventArgs e)
        {
            fontDialog1.AllowSimulations = false;
            fontDialog1.AllowVectorFonts = false;
            fontDialog1.AllowVerticalFonts = false;

            fontDialog1.ShowColor = true;
            fontDialog1.ShowApply = true;
            fontDialog1.ShowHelp = true;

            fontDialog1.MinSize = 10;
            fontDialog1.MaxSize = 20;

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                label2.Text = fontDialog1.Font.ToString();
                label2.ForeColor=fontDialog1.Color;
                label2.Font = fontDialog1.Font;
            }
        }

        private void btn_klasor_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.Description = "Klasör seçiniz.";
            folderBrowserDialog1.ShowNewFolderButton = false;
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                label3.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btn_ac_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Metin dosyaları|*.txt|Word Dosyaları|*.doc;*.docx|Tüm Dosyalar|*.*";
            openFileDialog1.AddExtension = true;
            openFileDialog1.DefaultExt = ".txt";
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;
            openFileDialog1.FileName = "";
            openFileDialog1.Multiselect = true;
            openFileDialog1.InitialDirectory = "C:\\Users\\Serkan\\Documents";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label4.Text = openFileDialog1.FileName;

                foreach (string dosyaAdi in openFileDialog1.SafeFileNames)
                {
                    listBox1.Items.Add(dosyaAdi);
                }

            }
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Metin dosyaları|*.txt";

            saveFileDialog1.AddExtension = true;
            saveFileDialog1.DefaultExt = ".txt";
            saveFileDialog1.CheckFileExists = false;
            saveFileDialog1.CheckPathExists = false;
            saveFileDialog1.FileName = "Belge";
            saveFileDialog1.InitialDirectory = "C:\\Users\\Serkan\\Documents";

            saveFileDialog1.CreatePrompt = true;
            saveFileDialog1.OverwritePrompt = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label5.Text = saveFileDialog1.FileName;
            }
        }

        private void btn_mesaj_Click(object sender, EventArgs e)
        {
            DialogResult mesaj = MessageBox.Show("Seçim yapınız", "Başlık", MessageBoxButtons.RetryCancel);
            label6.Text = mesaj.ToString();
        }

        private void colorDialog1_HelpRequest(object sender, EventArgs e)
        {
            label1.Text = "Yardım tuşuna basıldı.";
        }

        //Kurcala
        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        //Kurcala
        private void fontDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
