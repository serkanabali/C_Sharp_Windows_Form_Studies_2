﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;    //Sonradan eklenen kütüphaneler

namespace vtDeneme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //string baglantiDizesi = "Data Source=(local);" + "Initial Catalog=VT_NO_A_2023;" + "User ID=sa;" + "Password=123456*-";
        //Eğer Kullanıcı adı ve Şifre kullanılmıyorsav (Windows Authentication):
        //"User ID" ve "Password" yerine "Integrated Security=True" kullanılır

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=vtYeni;Integrated Security=True";

        private void Form1_Load(object sender, EventArgs e)
        {
            txt_ID.ReadOnly = true;
        }

        private void btn_veriEkle_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;
            komut.CommandText = "INSERT INTO Veriler VALUES(@kisi,@yer)";
            komut.Parameters.AddWithValue("@kisi", txt_isim.Text);
            komut.Parameters.AddWithValue("@yer", txt_Adres.Text);
            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Yeni Kayıt Oluşturuldu");
        }

        private void btn_listele_Click(object sender, EventArgs e)
        {
            SqlDataAdapter kopru = new SqlDataAdapter("SELECT * FROM Veriler", baglantiDizesi);
            DataTable tablo = new DataTable();
            kopru.Fill(tablo);
            dataGridView1.DataSource = tablo;
        }

        private void btn_veriGuncelle_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Veriler SET isim = @yeniIsim, adres = @yeniAdres WHERE id = @degisecekID";
            komut.Parameters.AddWithValue("@yeniIsim", txt_isim.Text);
            komut.Parameters.AddWithValue("@yeniAdres", txt_Adres.Text);
            komut.Parameters.AddWithValue("@degisecekID", txt_ID.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Güncelleme Başarılı");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Cell Click olayı hücrenin herhangi bir noktasına tıklandığı zaman çalışır.
            txt_ID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txt_isim.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_Adres.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Cell CONTENT Click olayı yalnızca hücredeki yazı içeriğine tıkladığımız zaman çalışır.
        }

        private void btn_veriSilme_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);

            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;

            komut.CommandText = "DELETE FROM Veriler WHERE id=@silinecekID";
            komut.Parameters.AddWithValue("@silinecekID", txt_ID.Text);

            komut.ExecuteNonQuery();

            baglanti.Close();
            MessageBox.Show("Veri başarıyla silindi");
        }
    }
}
