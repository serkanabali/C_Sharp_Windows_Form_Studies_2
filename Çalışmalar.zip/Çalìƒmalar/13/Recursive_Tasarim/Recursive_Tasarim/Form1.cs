﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recursive_Tasarim
{
    public partial class Form1 : Form
    {
        //Global değişken
        int treeViewIndis = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.HorizontalScrollbar = true;
            numericUpDown1.Maximum = int.MaxValue;
        }

        //------------------------------------
        private int Faktoriyel(int sayi)
        {
            if (sayi <= 1)
            {
                return 1;
            }
            else
            {
                return sayi * Faktoriyel(sayi - 1);
            }
        }

        //Faktoriyel hesapla
        private void button1_Click(object sender, EventArgs e)
        {
            int sayi = (int)numericUpDown1.Value;

            listBox1.Items.Add(String.Format("{0} sayısının faktoriyeli = {1}", sayi));
            treeView1.Nodes.Add(String.Format("{0}! bileşenleri ", sayi));
            treeViewIndis++;

            for (int i = 0; i < sayi; i++)
            {
                treeView1.Nodes[treeViewIndis].Nodes.Add(String.Format("{0}! = {1}"));
            }
        }
        //------------------------------------

        //------------------------------------
        private int Asal(int sayi, int test)
        {
            if (test == 1)
            {
                return 1;
            }
            else
            {
                if (sayi % test == 0)
                {
                    return 0;
                }
                else
                {
                    return Asal(sayi, test - 1);
                }
            }
        }

        //Asal sayı mı?
        private void button3_Click(object sender, EventArgs e)
        {
            int sayi = (int)numericUpDown1.Value;

            int AsalMi = Asal(sayi, sayi / 2);
            if (AsalMi == 1)
            {
                listBox1.Items.Add(String.Concat(sayi, "Sayısı Asaldır"));
                treeView1.Nodes.Add(String.Concat(sayi, "Sayısı Asaldır"));
                treeViewIndis++;
            }
            else
            {
                listBox1.Items.Add(String.Concat(sayi, "SAyısı Asal Değildir"));
                treeView1.Nodes.Add(String.Concat(sayi, "SAyısı Asal Değildir"));
                treeViewIndis++;
            }
        }
        //------------------------------------

        //------------------------------------
        private int ebob(int sayi, int test)
        {
            if (test == 0)
            {
                return sayi;
            }
            else
            {
                return ebob(test, sayi % test);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int s1, s2, EbobDegisken, Ekokdegisken;
            s1 = (int)numericUpDown2.Value;
            s2 = (int)numericUpDown3.Value;

            EbobDegisken = ebob(s1, s2);
            Ekokdegisken = (s1 * s2) / EbobDegisken;

            listBox1.Items.Add(String.Format("{0} ve {1} değişkenlerinin EKOK değeri = {2}, EBOB değeri = {3}", s1, s2, Ekokdegisken, EbobDegisken));

            treeViewIndis++;
            treeView1.Nodes[treeViewIndis].Nodes.Add("En BÜYÜK ortak BÖLENİ = " + EbobDegisken);
            treeView1.Nodes[treeViewIndis].Nodes.Add("En KÜÇÜK ortak KATI = " + Ekokdegisken);
        }
        //------------------------------------

        //------------------------------------
        private bool Palindrom(string kelime)
        {
            if (kelime.Length <= 1)
            {
                return Palindrom(kelime.Substring(1, kelime.Length - 2));
            }
        }

        //Palindrom mu?
        private void button5_Click(object sender, EventArgs e)
        {
            string kelime = textBox1.Text;
            bool sonuc = Palindrom(kelime.ToLower().Replace(" ", string.Empty));

            if (sonuc)
            {
                listBox1.Items.Add(kelime + "Palindromdur");
                treeView1.Nodes.Add(kelime + "Palindromdur");
                treeViewIndis++;
            }
            else
            {
                listBox1.Items.Add(kelime + "Palindrom değil");
                treeView1.Nodes.Add(kelime + "Palindrom değil");
                treeViewIndis++;
            }
        }
        //------------------------------------

        //------------------------------------
        private int Fibonacci()
        {
            if (true)
            {

            }
            else
            {
                return Fibonacci;
            }
        }

        //Fibonacci hesapla
        private void button2_Click(object sender, EventArgs e)
        {
            int sayi = (int)numericUpDown1.Value;
            int sonuc = Fibonacci(sayi);
        }

        //------------------------------------
    }
}
