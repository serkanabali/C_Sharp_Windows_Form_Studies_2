﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Eklenen Kütüphaneler
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;
using VeriTablosu = Microsoft.Office.Interop.Excel.DataTable;
using Application = Microsoft.Office.Interop.Excel.Application;
using System.IO;
using System.Data.OleDb;

namespace BBP_NO_B_H12_ExcelDosyalar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Global Değişkenler

        string baglantiDizesi = "Data Source=(local);Initial Catalog=VT_NO_A_2023;User ID=sa;Password=123456*-";
        SqlConnection baglanti;
        DataSet cokluTablo;
        //-------------
        private void Form1_Load(object sender, EventArgs e)
        {
            baglanti = new SqlConnection(baglantiDizesi);
            string komutDizesi = "SELECT * FROM personel";


            SqlDataAdapter kopru = new SqlDataAdapter(komutDizesi,baglanti);

            DataTable tablo = new DataTable();

            kopru.Fill(tablo);

            dataGridView1.DataSource = tablo;


            dataGridView1.Columns[0].HeaderText = "Personel ID";
            dataGridView1.Columns[1].HeaderText = "Personel Adı";
            dataGridView1.Columns[2].HeaderText = "Personel Soyadı";
            dataGridView1.Columns[3].HeaderText = "Personel Birimi";
            dataGridView1.Columns[4].HeaderText = "Personel Yaşı";

            ExcelYukle();
        }

        private void cb_tablolar_SelectedIndexChanged(object sender, EventArgs e)
        {
            int secimIndisi = cb_tablolar.SelectedIndex;
            dataGridView1.DataSource = cokluTablo.Tables[secimIndisi];
        }

        private void ExcelYukle()
        {
            string excelBaglantiDizesi = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Excel\\DenemeExceli3.xlsx;Extended Properties=\"Excel 12.0 Xml; HDR=NO; IMEX=1\"";

            OleDbConnection excelBaglanti = new OleDbConnection(excelBaglantiDizesi);

            DataTable tekliTablo = new DataTable();

            cokluTablo = new DataSet();

            excelBaglanti.Open();

            tekliTablo = excelBaglanti.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,null);

            //Test için kullanıldı
            //OleDBSchemaTable içerisinde ne olduğunu incelemek için yazıldı
            dataGridView1.DataSource = tekliTablo;
            //---------------

            string[] excelSayfaAdlari = new string[tekliTablo.Rows.Count];
            int sayfaSayaci = 0;
            foreach (DataRow satir in tekliTablo.Rows)
            {
                excelSayfaAdlari[sayfaSayaci] = satir["TABLE_NAME"].ToString();
                sayfaSayaci++;
            }

            foreach (string sayfaAdi in excelSayfaAdlari)
            {
                string komutSatiri = String.Format("SELECT * FROM [{0}]", sayfaAdi);
                OleDbDataAdapter kopru = new OleDbDataAdapter(komutSatiri,excelBaglanti);

                DataTable kopruTablo = new DataTable();
                kopru.Fill(kopruTablo);
                cokluTablo.Tables.Add(kopruTablo);
                cb_tablolar.Items.Add(sayfaAdi.Trim('$','\''));
            }

            excelBaglanti.Close();
        }
        private void btn_excel_kaydet_sabit_Click(object sender, EventArgs e)
        {
            Application excelUygulama = new Application();

            Workbook excelCalismaKitabi = excelUygulama.Workbooks.Add();

            //DenemeExceli.xls
            //Çalışma sayfası bu şekilde kullanılırsa var olan sayfaya yeni bir sayfa eklenir
            //Worksheet excelCalismaSayfasi = excelCalismaKitabi.Worksheets.Add();


            //Aktif sayfayı çalışma sayfası olarak almak için kullanılır.
            //excelCalismaSayfasi = excelCalismaKitabi.ActiveSheet;

            //DenemeExceli.xls
            /*excelCalismaSayfasi.Cells[1, 1] = "Bilgisayar";
            excelCalismaSayfasi.Cells[2, 2] = "Programcılığı";
            excelCalismaSayfasi.Cells[3, 3] = "Normal";
            excelCalismaSayfasi.Cells[4, 4] = "Öğretim";*/

            //DenemeExceli.xls
            //excelCalismaKitabi.SaveAs(Path.GetFullPath("Excel\\DenemeExceli.xls"), Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);


            //DenemeExceli2.xls ve sonrası
            Worksheet excelCalismaSayfasi = excelCalismaKitabi.Worksheets["Sayfa1"];

            //DenemeExceli2.xls
            //excelCalismaSayfasi.Cells[0, 0] = "İstanbul"; -> Özel Durum Hatası Döndürür
            //excelCalismaSayfasi.Cells[0, 1] = "Gelişim"; -> Özel Durum Hatası Döndürür
            //excelCalismaSayfasi.Cells[1, 0] = "Üniversitesi"; -> Özel Durum Hatası Döndürür

            //Excel'de ilk gücre [1,1] noktasıdır.
            //excelCalismaSayfasi.Cells[1, 1] = "MYO";

            //DenemeExceli3.xlsx
            for (int i = 1; i < 5; i++)
            {
                excelCalismaSayfasi.Cells[1, i] = "Hücre " + i;
            }

            excelCalismaSayfasi.Name = "Yeni Sayfa";


            //DenemeExceli2.xls ve sonrası
            //İstenilirse çalışma kitabı yerine çalışma sayfası da kaydedilebilir.
            excelCalismaSayfasi.SaveAs(Path.GetFullPath("Excel\\DenemeExceli3.xlsx"), Type.Missing, Type.Missing, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            excelUygulama.Quit();

        }

        private void btn_Excel_Kaydet_DataGrid_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = "Belge.xlsx";
            saveFileDialog1.DefaultExt = ".xlsx";
            saveFileDialog1.AddExtension = true;
            saveFileDialog1.Filter = "Eski Excel Dosyaları|*.xls|Modern Excel Dosyaları|*.xlsx";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string dosyaYolu = saveFileDialog1.FileName;
                Application excel = new Application();

                Workbook kitap = excel.Workbooks.Add(Type.Missing);

                //Tek sayfa olduğu için sayfa numarası da verilebilir,
                //sayfa adı da verilebilir
                //veya aktif sayfa da seçilebilir.
                Worksheet sayfa = kitap.ActiveSheet;

                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    sayfa.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
                }

                for (int x = 0; x < dataGridView1.Rows.Count; x++)
                {
                    for (int y = 0; y < dataGridView1.Columns.Count; y++)
                    {
                        sayfa.Cells[x + 2, y + 1] = dataGridView1.Rows[x].Cells[y].Value;
                    }
                }

                sayfa.Name = "DataGrid Sonuçları";
                sayfa.SaveAs(dosyaYolu, Type.Missing, Type.Missing, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                excel.Quit();
            }
        }

    
    }
}
