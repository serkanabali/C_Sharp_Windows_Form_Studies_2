﻿namespace BBP_NO_B_H12_ExcelDosyalar
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_Excel_Kaydet_DataGrid = new System.Windows.Forms.Button();
            this.btn_excel_kaydet_sabit = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.cb_tablolar = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(776, 216);
            this.dataGridView1.TabIndex = 0;
            // 
            // btn_Excel_Kaydet_DataGrid
            // 
            this.btn_Excel_Kaydet_DataGrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Excel_Kaydet_DataGrid.Location = new System.Drawing.Point(454, 248);
            this.btn_Excel_Kaydet_DataGrid.Name = "btn_Excel_Kaydet_DataGrid";
            this.btn_Excel_Kaydet_DataGrid.Size = new System.Drawing.Size(334, 54);
            this.btn_Excel_Kaydet_DataGrid.TabIndex = 1;
            this.btn_Excel_Kaydet_DataGrid.Text = "Data Grid\'i Excel\'e Aktar";
            this.btn_Excel_Kaydet_DataGrid.UseVisualStyleBackColor = true;
            this.btn_Excel_Kaydet_DataGrid.Click += new System.EventHandler(this.btn_Excel_Kaydet_DataGrid_Click);
            // 
            // btn_excel_kaydet_sabit
            // 
            this.btn_excel_kaydet_sabit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_excel_kaydet_sabit.Location = new System.Drawing.Point(12, 248);
            this.btn_excel_kaydet_sabit.Name = "btn_excel_kaydet_sabit";
            this.btn_excel_kaydet_sabit.Size = new System.Drawing.Size(334, 54);
            this.btn_excel_kaydet_sabit.TabIndex = 1;
            this.btn_excel_kaydet_sabit.Text = "Sabit Bilgiyi Excel\'e Aktar";
            this.btn_excel_kaydet_sabit.UseVisualStyleBackColor = true;
            this.btn_excel_kaydet_sabit.Click += new System.EventHandler(this.btn_excel_kaydet_sabit_Click);
            // 
            // cb_tablolar
            // 
            this.cb_tablolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cb_tablolar.FormattingEnabled = true;
            this.cb_tablolar.Location = new System.Drawing.Point(153, 339);
            this.cb_tablolar.Name = "cb_tablolar";
            this.cb_tablolar.Size = new System.Drawing.Size(193, 37);
            this.cb_tablolar.TabIndex = 2;
            this.cb_tablolar.Text = "Tablo Seç...";
            this.cb_tablolar.SelectedIndexChanged += new System.EventHandler(this.cb_tablolar_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(27, 347);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tablo Adı";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_tablolar);
            this.Controls.Add(this.btn_excel_kaydet_sabit);
            this.Controls.Add(this.btn_Excel_Kaydet_DataGrid);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_Excel_Kaydet_DataGrid;
        private System.Windows.Forms.Button btn_excel_kaydet_sabit;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox cb_tablolar;
        private System.Windows.Forms.Label label1;
    }
}

