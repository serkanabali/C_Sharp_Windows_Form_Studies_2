﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recursive_Tasarim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Global değişkenler
        int treeViewIndis = -1;
        //-----------
        private int Faktoriyel(int sayi)
        {
            if (sayi <= 1)
            {
                return 1;
            }
            else
            {
                return sayi * Faktoriyel(sayi - 1);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int sayi = (int)numericUpDown1.Value;

            listBox1.Items.Add(String.Format("{0} sayısının faktoriyeli = {1}", sayi, Faktoriyel(sayi)));

            treeView1.Nodes.Add(String.Format("{0}! bileşenleri", sayi));
            treeViewIndis++;
            for (int i = 1; i <= sayi; i++)
            {
                treeView1.Nodes[treeViewIndis].Nodes.Add(String.Format("{0}! = {1}", i, Faktoriyel(i)));
            }

        }

        private int Asal(int sayi, int test)
        {
            if (test == 1)
            {
                return 1;
            }
            else
            {
                if (sayi % test == 0)
                {
                    return 0;
                }
                else
                {
                    return Asal(sayi, test - 1);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            int sayi = (int)numericUpDown1.Value;

            int AsalMi = Asal(sayi, sayi / 2);
            if (AsalMi == 1)
            {
                listBox1.Items.Add(String.Concat(sayi, " Sayısı Asaldır"));
                treeView1.Nodes.Add(String.Concat(sayi, " Sayısı Asaldır"));
                treeViewIndis++;
            }
            else
            {
                listBox1.Items.Add(String.Concat(sayi, " Sayısı Asal Değildir"));
                treeView1.Nodes.Add(String.Concat(sayi, " Sayısı Asal Değildir"));
                treeViewIndis++;
            }
        }

        private int Ebob(int sayi, int test)
        {

            if (test == 0)
            {
                return sayi;
            }
            else
            {
                return Ebob(test, sayi % test);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int s1, s2, EbobDegisken, EkokDegisken;
            s1 = (int)numericUpDown2.Value;
            s2 = (int)numericUpDown3.Value;

            EbobDegisken = Ebob(s1, s2);
            EkokDegisken = (s1 * s2) / EbobDegisken;

            listBox1.Items.Add(String.Format("{0} ve {1} değişkenlerinin EKOK değeri = {2}, EBOB değeri = {3}", s1, s2, EkokDegisken, EbobDegisken));
            treeView1.Nodes.Add(String.Format("{0} ve {1} sayılarının:", s1, s2));
            treeViewIndis++;
            treeView1.Nodes[treeViewIndis].Nodes.Add("En Büyük Ortak Böleni = " + EbobDegisken);
            treeView1.Nodes[treeViewIndis].Nodes.Add("En Küçük Ortak Katı = " + EkokDegisken);
        }

        private int Fibonacci(int sayi)
        {
            if (sayi <= 0)
            {
                return 0;
            }
            else if (sayi==1)
            {
                return 1;
            }
            else
            {
                return Fibonacci(sayi - 1) + Fibonacci(sayi - 2);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int sayi = (int) numericUpDown1.Value;

            int sonuc = Fibonacci(sayi);

            listBox1.Items.Add(String.Format("Fib({0}) Sonucu = {1}", sayi, sonuc));
            treeView1.Nodes.Add(String.Format("Fib({0}) Sonuç = {1}", sayi, sonuc));
            treeViewIndis++;
        }
        
        private bool Palindrom(string kelime)
        {
            if (kelime.Length <= 1)
            {
                return true;
            }
            else
            {
                if (kelime.First() == kelime.Last())
                {
                    return Palindrom(kelime.Substring(1, kelime.Length - 2));
                }
                else
                {
                    return false;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string kelime = textBox1.Text;

            bool sonuc = Palindrom(kelime.ToLower().Replace(" ", string.Empty));

            if (sonuc)
            {
                listBox1.Items.Add(kelime + " Palindromdur");
                treeView1.Nodes.Add(kelime + " Palindromdur");
                treeViewIndis++;
            }
            else
            {
                listBox1.Items.Add(kelime + " Palindrom Değildir");
                treeView1.Nodes.Add(kelime + " Palindrom Değildir");
                treeViewIndis++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.HorizontalScrollbar = true;
            numericUpDown1.Maximum = int.MaxValue;
        }

  
    }
}
